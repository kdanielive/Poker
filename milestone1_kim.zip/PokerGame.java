import java.util.*;
/**
plays the poker game
@author Daniel Kim
@version 04/11/2017
*/
public class PokerGame
{
   /** array of players in the game */
   private Player[] players = new Player[5];
   /** the deck of poker cards being used in game */
   private Deck deck = new Deck();
   /** the betting money on table */
   private int moneyOnTable;
   /** the number of turns passed in the game */
   private int turn;
   /** the communicty cards of the game */
   private ArrayList<PokerCard> communityCards = new ArrayList<PokerCard>();
   
   /**
   plays the poker game
   */
   public void playGame()
   {
   }
   
   /**
   ends the poker game
   */
   public void endGame()
   {
   }
   
   /**
   compares the hands of two players and decides the winner
   @param player1 the first player of hand comparison
   @param player2 the second player of hand comparison
   */
   public void compareHands(Player player1, Player player2)
   {
   
   }
   
   public static void main(String[] args)
   {
      /*
      Deck deck1 = new Deck();
      for(int idx = 0; idx < Deck.cardNum; idx++)
      {
         System.out.println(deck1.drawCard().getName());
      }
      */
      
      AIPlayer Joe = new AIPlayer("Mount and Blade" ,"Chappaqua", 300, "Easy");
      
      System.out.println(Joe.getName());
      System.out.println(Joe.getIcon());
      System.out.println(Joe.getFinance());
   }
}